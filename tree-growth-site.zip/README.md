
# Tree Growth Tracker Site

## Setup

```bash
pnpm i
pnpm run dev
```

Replace `API_URL` placeholders in `src/*.js` with your Apps Script Web App URL.

## Build & Deploy

```bash
pnpm run build
# push dist to GitHub Pages or use the provided CI workflow
```
